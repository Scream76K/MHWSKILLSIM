# MHWilds Simulator Specifications v3.6.0

Specification Phase Closure / Combo Development Readiness delta.

This release closes the initial architecture/specification phase.
Future specification changes are driven by verified implementation/research findings.

Next primary development stream:
Combo DPS data acquisition, formula verification, Technique DB, Combo DB and Golden Fixtures.
