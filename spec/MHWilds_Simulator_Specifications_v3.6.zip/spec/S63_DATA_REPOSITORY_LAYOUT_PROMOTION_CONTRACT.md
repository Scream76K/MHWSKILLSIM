# S63 — Data Repository Layout & Promotion Contract

Status: ADOPTED

## Purpose
Separate investigation from trusted production data.

## Data stages
`research -> candidate -> production -> historical/archive`

### research
Raw observations, source captures, notes, incomplete extraction and experiments.
May contain contradictions and unknowns. Never consumed as production truth.

### candidate
Normalized/schema-valid data proposed for adoption.
Requires reference/domain/evidence validation.

### production
Intentionally adopted data allowed for deterministic simulator use and AI retrieval subject to
verification/version rules.

### historical/archive
Superseded versioned records retained for reproducibility.

## Recommended layout
```text
data/
  research/
    sources/
    evidence/
    techniques/
    formulas/
    builds/
    talismans/
    monsters/
  candidate/
    techniques/
    formulas/
    combos/
    builds/
    talismans/
    monsters/
  production/
    manifests/
    sources/
    evidence/
    techniques/
    formulas/
    combos/
    builds/
    talismans/
    monsters/
    fixtures/
  historical/
```

## Promotion
Promotion is explicit. Copying a file into production is not sufficient; validation status,
version context, evidence and required regression must pass.

## Rule
Application runtime SHOULD consume production data only, except explicit developer/research tools.
