# S66 — Combo Development Definition of Ready

Status: ADOPTED

## Purpose
Define when the project can move from specification-first work into production Combo DPS research.

## Ready conditions
The project has:
- game baseline/version traceability,
- Source/Evidence model,
- stable ID/reference model,
- Technique schema,
- Formula Registry contract,
- Calculation Trace contract,
- Combo DPS result contract,
- Golden Fixture contract,
- update/version migration model,
- research/candidate/production separation,
- validation/promotion rules.

These conditions are now considered satisfied at the specification level.

## First execution sequence
1. inventory existing combo/technique implementation and retained data,
2. inventory verified external/official evidence already collected,
3. define current formula evidence table for Ver.1.042.00.02,
4. identify UNKNOWN formula components,
5. select first weapon as a vertical slice,
6. build Technique records,
7. build representative Combo records,
8. generate calculation traces,
9. create Golden Fixtures,
10. compare with retained simulator/external references,
11. fix discrepancies before scaling to all 14 weapons.

## Scaling rule
Do not mass-import all 14 weapon types before one vertical slice proves the data/formula/fixture
pipeline.

## Existing data
Existing project combo work is valuable input but must be classified by evidence/version status
rather than automatically assumed current.
