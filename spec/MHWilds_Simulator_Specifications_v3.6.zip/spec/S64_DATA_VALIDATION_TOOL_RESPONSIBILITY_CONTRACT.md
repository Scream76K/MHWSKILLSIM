# S64 — Data Validation / Tool Responsibility Contract

Status: ADOPTED

## Validators
The project should maintain deterministic validation for:
1. schema shape
2. ID uniqueness
3. reference integrity
4. game-version compatibility
5. domain constraints
6. evidence requirements
7. formula dependency cycles
8. fixture validity
9. stale dependency detection

## Collector vs validator
A collector/importer may create research/candidate data. It must not silently certify it.

## Build gate
Production data validation failure is a release blocker when the affected data are shipped/used.

## Reports
Validation output SHOULD identify record ID, failing rule, severity and actionable location.

## AI
AI may assist research extraction/classification, but deterministic validation and adopted evidence
state control production eligibility.
