# S65 — Spec-to-Implementation Traceability Contract

Status: ADOPTED

## Purpose
Avoid a growing gap between documentation and code.

## Traceability map
Important implementation modules/functions/data files SHOULD be mappable to governing Spec sections.

Conceptual record:
`implementationRef -> specRefs -> dataRefs -> fixtureRefs -> status`.

## Change rule
When behavior changes:
1. identify governing Spec,
2. decide whether behavior or Spec is wrong/outdated,
3. update intentionally,
4. update regression evidence.

## No documentation theater
A Spec marked ADOPTED that is knowingly not implemented must be labelled planned/partial rather than
presented as completed behavior.

## Reverse engineering
Observed legacy/current implementation facts remain implementation evidence; they do not override
adopted normative Spec without an explicit decision.
