# S67 — Specification Phase Closure Decision

Status: ADOPTED DECISION

## Decision
The initial specification-foundation phase is sufficiently mature to stop treating further Spec
expansion as the primary workstream.

## Next primary workstream
Combo DPS.

Parallel secondary workstream:
Build Template DB expansion and God Talisman knowledge collection.

## Ongoing Spec policy
Specifications remain living documents. Update them when:
- research reveals a verified rule,
- implementation exposes an architectural mismatch,
- a game update changes dependencies,
- a new subsystem requires an explicit contract,
- regression evidence proves an existing assumption wrong.

Do not create speculative Spec merely to increase document count.

## Development loop
`research -> evidence -> candidate data/rule -> decision -> Spec when needed ->
implementation/data promotion -> regression -> release`

## AI timing
AI Support implementation remains downstream of sufficient production-quality Combo, Build and
Talisman data. Data quality is the current priority.
