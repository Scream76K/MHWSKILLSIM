# CHANGELOG

## 3.6.0
- Added S63 Data Repository Layout & Promotion Contract.
- Added S64 Data Validation / Tool Responsibility Contract.
- Added S65 Spec-to-Implementation Traceability Contract.
- Added S66 Combo Development Definition of Ready.
- Added S67 Specification Phase Closure Decision.
- Added recommended repository tree and combo-start checklist.
